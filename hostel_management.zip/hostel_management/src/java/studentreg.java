/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import database.Dbconfig;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DELL
 */
public class studentreg extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
                    ZoneId indiaZone = ZoneId.of("Asia/Kolkata");

        // Get the current date and time in IST
        ZonedDateTime indiaTime = ZonedDateTime.now(indiaZone);

        // Format the date and time
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String hostel_id1=request.getParameter("hostel_id1");
            String student_name=request.getParameter("student_name");
            String room_no=request.getParameter("room_no");
            String phno=request.getParameter("phno");
            String date=request.getParameter("dob");
            String email=request.getParameter("email");
            String father_name=request.getParameter("father_name");
            String father_no=request.getParameter("father_no");
            String mother_name=request.getParameter("mother_name");
            String parent_occupation=request.getParameter("parent_occupation");
            String religion=request.getParameter("religion");
            String caste=request.getParameter("caste");
            String address=request.getParameter("address");
            String adhaar_number=request.getParameter("adhaar_number");
            String course=request.getParameter("course");
            String branch=request.getParameter("branch");
            String joining_date= indiaTime.format(formatter);
            String password=request.getParameter("password");
            String cpassword=request.getParameter("cpassword");
           // String tfees=request.getParameter("tfees");
        try {

            if(password.equals(cpassword))
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con1= new Dbconfig().getconnection();
                Statement stat1=con1.createStatement();
                stat1.executeUpdate("INSERT INTO student_register (hostel_id1,student_name,room_no,phno,dob,email,father_name,father_no,mother_name,parent_occupation,religion,caste,address,adhaar_number,course,branch,joining_date,password) Values ('"+hostel_id1+"','"+student_name+"','"+room_no+"','"+phno+"','"+date+"','"+email+"','"+father_name+"','"+father_no+"','"+mother_name+"','"+parent_occupation+"','"+religion+"','"+caste+"','"+address+"','"+adhaar_number+"','"+course+"','"+branch+"','"+joining_date+"','"+password+"')");
                stat1.executeUpdate("insert into payments(hostel_id1,tfees) values('"+hostel_id1+"')");
                stat1.executeUpdate("insert into check_in(hostel_id1,check_in) values('"+hostel_id1+"','"+checkin+"')");
                out.print("<script>alert('successfully')</script>");
                out.print("<META http-equiv=\"refresh\" content=\"0;wardenmenu.jsp\">");
                
            }
            else
            {
                out.print("<script>alert('not successful')</script>");
            }
            
        } catch (Exception e) {
                out.print("insert into check_in(hostel_id1,check_in) values('"+hostel_id1+"','"+checkin+"')");
            out.print(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
